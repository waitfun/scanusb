{
    复制到本地的目录
    "backupPath": "E:/backup",
    复制的文件类型
    "mateAss": [
        ".doc",
        ".docx",
        ".pdf",
        ".ppt",
        ".pptx",
        ".jpg",
        ".png"
    ],
    usb的名称
    "usbPath": [
        "D:/",
        "F:/",
        "G:/",
        "H:/"
        
    ],
    "复制本地或者远程":"True为本地，False为远程",
    "remoteORlocal": "False",
    "服务器配置":"",
    服务器IP地址
    "server_ip" : "193.112.61.333",
    服务器用户名
    "server_user" :"username",
    服务器登录密码
    "server_passwd" :"password",
    服务器端口22，不用改
    "server_port" :22,
    "远程目录配置":"",
    "remote_dir" :"/var/www/html/upan"
}